<div class="form-group">
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
</div>


<!-- Thumbnail Taroh diatas  -->
<div class="form-group">
  <div class="col-sm-12">
    <div class="panel panel-default">
      <div class="panel-heading text-center">
        <b>Edit Gambar Artikel Kegiatan Desa</b>
      </div>
      <div class="panel-body text-center">
        <img id="preview" src="<?php echo e(asset('images-kegiatan-desa/'.$activity->thumbnail)); ?>" alt="preview" width="1000px" height="380">
        <div class="col-sm-12" style="margin-top: 10px; display: none;">
          <?php echo Form::file('thumbnail', ['id' => 'image']); ?>

        </div>
        <a href="javascript:changeProfile()" class="btn btn-success pull-right" style="margin-top: 10px;"> <i class="fa fa-upload"></i> Pilih Gambar </a>
      </div>
    </div>
  </div>
</div>



<div class="form-group">
  <label class="col-sm-2">Judul Artikel</label>
  <div class="col-sm-12">
    <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'Masukkan Judul Artikel....']); ?>

  </div>
</div>

<div class="form-group">
  <label class="col-sm-2">Isi Artikel</label>
  <div class="col-sm-12">
    <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Masukkan Isi Artikel....', 'rows' => '20']); ?>

  </div>
</div>
