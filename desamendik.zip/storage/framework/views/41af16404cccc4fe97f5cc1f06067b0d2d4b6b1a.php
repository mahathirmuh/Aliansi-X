<?php $__env->startSection('content'); ?>


  <div class="container" style="width: 90%;">
    <div class="kegiatan">
      <div class="box">
        <div class="header-kegiatanlain">
          <div class="box-header">
            <h3> <b>Struktur Organisasi Desa Mendik</b> </h3>
          </div>
        </div>
        <div class="box-body">
          <div class="struktur">
            <div class="container">
              <?php $__currentLoopData = $structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Structure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-xs-4 col-lg-2">
                <div class="box-img">
                  <div class="container-inner">
                    <img src="<?php echo e(asset('images-struktur/'.$Structure->photo)); ?>" alt="Kades" class="image">
                    <div class="overlay">
                      <div class="text">
                        <p><?php echo e($Structure->nama); ?></p>
                        <p><?php echo e($Structure->jabatan); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>