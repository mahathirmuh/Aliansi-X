<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <link rel="stylesheet" href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Desa Mendik</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <link rel="icon" href="<?php echo e(asset('img/favicon-16x16.png')); ?>">

        <!-- Styles -->
    </head>
    <body>
        <div class="header">
          <div class="col-xs-12">
            <div class="col-xs-2 col-lg-2">
              <a href="http://www.paserkab.go.id/home/web"><img src="<?php echo e(asset('img/daya-taka-colour_burned.png')); ?>" alt="logo desa" id="logo_desa"></a>
            </div>
            <div class="col-xs-8 col-lg-8">
              <a href="<?php echo e(url('/')); ?>"> <p>Selamat Datang di Website <br>Desa Mendik <br>Agamis, Mandiri, Berbudaya dan Sejahtera</p> </a>
            </div>
            <div class="col-xs-2 col-lg-2">
              <a href="http://www.unmul.ac.id/"><img src="<?php echo e(asset('img/Logo-Unmul-2.png')); ?>" alt="logo_unmul" id="logo_unmul"></a>
            </div>
          </div>
        </div>
        <!-- End of Header -->
        <div class="navigation">
          <nav class="navbar navbar-blue">
            <div class="container-fluid">
                <ul class="nav navbar-nav navbar-center">
                  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                  <li><a href="<?php echo e(url('/kegiatan-desa')); ?>">Kegiatan Desa</a></li>
                  <li><a href="<?php echo e(url('/struktur-organisasi')); ?>">Struktur Organisasi Desa</a></li>
                  <li><a href="#">Peta Desa Mendik</a></li>
                </ul>
            </div>
          </nav>
        </div>
        <!-- <End of Navbar> -->

        <section class="content">
            <?php echo $__env->yieldContent('content'); ?>
            <!-- End of Content -->
        </section>

        <footer>
          <div class="copyright">
            <b>
              © 2018 Copyright: <a href="https://www.instagram.com/kkn44_desamendik/"> KKN 44 UNMUL Desa Mendik</a>
              Design/Code by <a href="https://www.facebook.com/widyatamathebluedemon">TamaGotchii</a>
            </b>
          </div>
        </footer>
        <!-- End of Footer -->
        <script src="<?php echo e(asset('asset/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('asset/js/bootstrap.min.js')); ?>" charset="utf-8"></script>
    </body>
</html>
