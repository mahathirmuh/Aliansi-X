<div class="form-group">
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
</div>


<!-- Thumbnail Taroh diatas  -->
<div class="form-group">
  <div class="col-sm-12">
    <div class="panel panel-default">
      <div class="panel-heading text-center">
        <b>Gambar Artikel Potensi</b>
      </div>
      <div class="panel-body text-center">
        <img id="preview" src="http://via.placeholder.com/1000x380" alt="preview" width="1000px" height="380px">
        <div class="col-sm-12" style="margin-top: 10px; display: none;">
          <?php echo Form::file('thumbnail', ['id' => 'image']); ?>

        </div>
        <a href="javascript:changeProfile()" class="btn btn-success pull-right" style="margin-top: 10px;"> <i class="fa fa-upload"></i> Pilih Gambar </a>
      </div>
    </div>
  </div>
</div>



<div class="form-group">
  <label class="col-sm-12">Judul Artikel Kegiatan Desa</label>
  <div class="col-sm-12">
    <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'Masukkan Judul Artikel....']); ?>

  </div>
</div>

<div class="form-group">
  <label class="col-sm-12">Isi Artikel Kegiatan Desa</label>
  <div class="col-sm-12">
    <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Masukkan Isi Artikel....', 'rows' => '20']); ?>

  </div>
</div>
